package app.killddl.killddl.calendarscreen;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import app.killddl.killddl.mainscreen.LoginSetup;

@RunWith(Suite.class)
@Suite.SuiteClasses({LoginSetup.class, CalendarScreenTest.class
})
public class CalendarScreenSuiteTest {
}
