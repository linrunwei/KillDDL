package app.killddl.killddl.profilescreen;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import app.killddl.killddl.mainscreen.LoginSetup;

@RunWith(Suite.class)
@Suite.SuiteClasses({LoginSetup.class, ProfileScreenTest.class
})
public class ProfileScreenSuiteTest {
}
