package app.killddl.killddl.addtaskscreen;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import app.killddl.killddl.addtaskscreen.AddTaskScreenTest;
import app.killddl.killddl.mainscreen.LoginSetup;

@RunWith(Suite.class)
@Suite.SuiteClasses({LoginSetup.class, AddTaskScreenTest.class
})
public class AddTaskScreenSuiteTest {
}
